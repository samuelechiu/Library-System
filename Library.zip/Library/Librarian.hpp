//
//  Librarian.hpp
//  library
//
//  Created by Sam on 4/23/19.
//  Copyright © 2019 Samuel Chiu. All rights reserved.
//

#ifndef Librarian_hpp
#define Librarian_hpp

#include <stdio.h>
#include <iostream>
#include "User.hpp"


using namespace std;
class Librarian : public User{
public:
    Librarian();
    void addBook();
    
};
#endif /* Librarian_hpp */
