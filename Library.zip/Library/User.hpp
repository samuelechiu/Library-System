//
//  User.hpp
//  library
//
//  Created by Sam on 4/23/19.
//  Copyright © 2019 Samuel Chiu. All rights reserved.
//

#ifndef User_hpp
#define User_hpp

#include <stdio.h>
#include <string>
#include <iostream>
#include <fstream>

using namespace std;

class User{
public:
    User();
    User(string u, string p);
    
    void setUserNum(int uNum);
    int  getUserNum();
    void setUsername(string u);
    string getUsername();
    void setPassword(string p);
    string getPassword();
    void setRole(string r);
    string getRole();
    int validateUser(string p, string u, string *r);
    bool doesBookExist(string isbn, int *lastBookRec);
    bool searchBook(string i);
    
    
protected:
    int userNum;
    string username;
    string password;
    string role;
};
#endif /* User_hpp */
