//
//  Customer.hpp
//  library
//
//  Created by Sam on 4/23/19.
//  Copyright © 2019 Samuel Chiu. All rights reserved.
//

#ifndef Customer_hpp
#define Customer_hpp

#include <iostream>
#include <stdio.h>
#include <fstream>
#include <string>
#include "User.hpp"
using namespace std;

class Customer : public User{
public:
    Customer();
    
    
};
#endif /* Customer_hpp */
