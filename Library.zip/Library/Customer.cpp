//
//  Customer.cpp
//  library
//
//  Created by Sam on 4/23/19.
//  Copyright © 2019 Samuel Chiu. All rights reserved.
//

#include "Customer.hpp"

using namespace std;

Customer::Customer() {
    
}

