//
//  main.cpp
//  library
//
//  Created by Sam on 4/23/19.
//  Copyright © 2019 Samuel Chiu. All rights reserved.
//

#include <string>
#include <iostream>
#include <fstream>
#include "User.hpp"
#include "Customer.hpp"
#include "Librarian.hpp"

using namespace std;


int main() {
    
    int validated = 0;
    string uName;
    string uPassword;
    string uRole;
    User *usr;
    Customer *customer;
    Librarian *librarian;
    
    cout << "************************Welcome to the library system************************" << endl;
    
    // Everyone is given 3 attempts to login
    for (int i = 0; i < 3; i++)
    {
        cout << "User ID: ";
        getline(cin, uName);
        
        cout << "Password: ";
        getline(cin, uPassword);
        
        usr = new User(uName, uPassword);
        
        validated = usr->validateUser(uName, uPassword, &uRole);
        
        delete usr;
        
        if (validated == 0)
        {
            if (i < 2)
            {
                cout << "Please check your user ID and password, you have " << (3 - i - 1) << " tries remaining..." << endl;
            }
            else
            {
                cout << "Sorry you used all your login attempts, goodbye." << endl;
            }
        }
        else
        {
            if (validated != -1)
            {
                // User found, display role
                cout << "Welcome " << uName << ", your role is " << uRole << endl;
            }
            break;
        }
    }
    
    if (validated > 0)
    {
        // Present menu options according to role
        if (uRole == "customer")
        {
            int input;
            string isbn;
            customer = new Customer();
            cout << "Menu: " << endl << "1: Check book status" << endl << "2: Exit" << endl;
            cout << "Input option: ";
            cin >> input;
            switch (input)
            {
                case 1:
                    cout << "Input ISBN" << endl;
                    cin >> isbn;
                    customer->searchBook(isbn);
                case 2:
                    cout << "Have a good day!";
                    break;
            }
        }
        else
        {
            int input;
            string isbn;
            librarian = new Librarian();
            cout << "Menu: " << endl << "1: Check book status" << endl << "2: Add a book" << endl << "3: Exit" << endl;
            cout << "Input option: ";
            cin >> input;
            switch (input)
            {
                case 1:
                    cout << "Input ISBN" << endl;
                    cin >> isbn;
                    librarian->searchBook(isbn);
                case 2:
                    librarian->addBook();
            }
        }
    }
    
    return 0;
}
