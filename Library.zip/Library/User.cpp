//
//  User.cpp
//  library
//
//  Created by Sam on 4/23/19.
//  Copyright © 2019 Samuel Chiu. All rights reserved.
//


#include "User.hpp"

using namespace std;

User::User()
{
    username = "";
    password = "";
}

User::User(string u, string p)
{
    username = u;
    password = p;
}

void User::setUserNum(int uNum)
{
    userNum = uNum;
}

int User::getUserNum()
{
    return userNum;
}

void User::setUsername(string u)
{
    username = u;
}

string User::getUsername()
{
    return username;
}

void User::setPassword(string p)
{
    password = p;
}

string User::getPassword()
{
    return password;
}

void User::setRole(string r)
{
    role = r;
}

string User::getRole()
{
    return role;
}

int User::validateUser(string u, string p, string *r)
{
    string pwdFileName = "credential.txt⁩";
    string pwdLine;
    char *str = NULL;
    bool matchedUser = false;
    bool matchedPwd = false;
    int matchedUserNum = 0;
    
    int userNum = 0;
    int pos = 0;
    
    ifstream pwdFile;
    ifstream pwdLockFile;

    pwdFile.exceptions(ifstream::eofbit | ifstream::badbit | ifstream::failbit);

    try
    {
        pwdFile.open(pwdFileName);
        
        while (!pwdFile.eof())
        {
            // Reset variables that may change in each line read
            pos = 0;
            userNum = 0;
            matchedUser = false;
            matchedPwd = false;
            matchedUserNum = 0;
            
            getline(pwdFile, pwdLine);
            
            // Tokenize each line to check for user ID and password
            str = strtok((char *) pwdLine.c_str(), "|");
            
            while (str != NULL)
            {
                // First token is the user number, needs to convert it to integer
                if (pos == 0)
                {
                    userNum = atoi(str);
                    // cout << "User rec: " << userNum << endl;
                }
                else if (pos == 1)
                {
                    // This is user's role
                    // cout << "Role: " << str << endl;
                    *r = str;
                }
                else if (pos == 2)
                {
                    // This is user ID
                    // cout << "User ID: " << str << endl;
                    
                    if (strcmp(str, u.c_str()) == 0)
                    {
                        matchedUser = true;
                    }
                }
                else if (pos == 3)
                {
                    // This is password
                    // cout << "Password: " << str << endl;
                    
                    if (strcmp(str, p.c_str()) == 0)
                    {
                        matchedPwd = true;
                    }
                }
                
                if ((matchedUser == true) && (matchedPwd == true))
                {
                    // Set matchedUserNum to current userNum, and store the role and return
                    matchedUserNum = userNum;
                    return matchedUserNum;
                }
                
                str = strtok(NULL, "|");
                
                pos++;
                
            }
        }
    }
    catch (ifstream::failure f)
    {
        if (errno != 0)
        {
            cout << "File exception: " << strerror(errno) << endl;
        }
        return -1;
    }
    
    return 0;
}



bool User::doesBookExist(string isbn, int *lastBookRec)
{
    bool bookExist = false;
    
    // string bookFileName = "C:\\Code\\Books\\Debug\\books.txt";
    string bookFileName = "books.txt";
    
    string bookLine;
    char *str = NULL;
    
    int bookRec = 0;
    int pos = 0;
    int numOfBooks = 0;
    
    ifstream bookFile;
    
    
    bookFile.exceptions(ifstream::eofbit | ifstream::badbit | ifstream::failbit);
    
    try
    {
        bookFile.open(bookFileName);
        
        while (!bookFile.eof())
        {
            getline(bookFile, bookLine);
            
            if (!bookLine.empty())
            {
                pos = 0;
                bookRec = 0;
                
                numOfBooks++;
                
                str = strtok((char *)bookLine.c_str(), "|");
                
                while (str != NULL)
                {
                    if (pos == 0)
                    {
                        bookRec = atoi(str);
                    }
                    else if (pos == 3)
                    {
                        if (strcmp(str, isbn.c_str()) == 0)
                        {
                            bookExist = true;
                        }
                    }
                    
                    str = strtok(NULL, "|");
                    
                    pos++;
                    
                }
            }
        }
    }
    catch (ifstream::failure f)
    {
        if (errno != 0)
        {
            cout << "File exception: " << strerror(errno) << endl;
        }
        // return -1;
    }
    
    *lastBookRec = numOfBooks;
    
    bookFile.close();
    
    return bookExist;
}

bool User::searchBook(string i) {
    string bookFileName = "books.txt";
    string bookLine;
    string isbn;
    bool recordfound = false;
    int pos;
    int recnum;
    char *str = NULL;
    
    ifstream bookFile;
    
    bookFile.exceptions(ifstream::eofbit | ifstream::badbit | ifstream::failbit);
    
    try {
        bookFile.open(bookFileName);
        
        while (!bookFile.eof())
        {
            pos = 0;
            getline(bookFile, bookLine);
            str = strtok((char *)bookLine.c_str(), "|");
            
            while (str != NULL)
            {
                if (pos == 0)
                {
                    recnum = atoi(str);
                }
                else if (pos == 3)
                {
                    if (strcmp(str, i.c_str()) == 0)
                    {
                        cout << "Book exists" << endl;
                        recordfound = true;
                    }
                }
                else if (pos == 6)
                {
                    if (recordfound)
                    {
                        if (atoi(str) == 1)
                        {
                            cout << "Book is available for checkout" << endl;
                        }
                        else
                        {
                            cout << "Book is not available for checkout" << endl;
                        }
                    }
                }
                
                str = strtok(NULL, "|");
                
                pos++;
            }
        }
        
        
    }
    catch (ifstream::failure f) {
        if (errno != 0)
        {
            cout << "File exception: " << strerror(errno) << endl;
        }
        //        return -1;
    }
    
    return true;
}

