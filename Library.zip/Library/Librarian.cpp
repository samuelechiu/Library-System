//
//  Librarian.cpp
//  library
//
//  Created by Sam on 4/23/19.
//  Copyright © 2019 Samuel Chiu. All rights reserved.
//

#include "Librarian.hpp"
using namespace std;

Librarian::Librarian()
{
    username = "";
    password = "";
}

void Librarian::addBook()
{
    bool bookExist = false;
    int lastBookRec = 0;
    
    string title;
    string author;
    string isbn;
    int year;
    string publisher;
    string newBookRecord;
    
    // Get user to enter book info
    cout << "Please enter the information of the book to add " << endl;
    
    cout << "Title: ";
    cin >> title;
    // getline(cin, title);
    cout << "Author: ";
    cin >> author;
    // getline(cin, author);
    cout << "ISBN: ";
    cin >> isbn;
    
    // getline(cin, isbn);
    cout << "Year of publication: ";
    // getline(cin, year);
    cin >> year;
    do
    {
        cin >> year;
        cout << "Invalid year. Please try again" << endl;
    } while ((year > 9999) || (year < 1000));
    string yr = to_string(year);
    cout << "Publisher: ";
    // getline(cin, publisher);
    cin >> publisher;
    
    // Add book
    // First check if the book exist, if so don't add a redundant book
    bookExist = doesBookExist(isbn, &lastBookRec);
    
    if (!bookExist)
    {
        // Just add the book record to the end of the book.txt
        // First increment last book record
        lastBookRec++;
        
        newBookRecord += to_string(lastBookRec) + "|" + title + "|" + author + "|" + isbn + "|" + yr + "|" + publisher;
        
        cout << newBookRecord << endl;
        
        // Open an outfile stream, and append the string to the end
        // string bookFileName = "C:\\Code\\Books\\Debug\\books.txt";
        string bookFileName = "books.txt";
        ofstream bookFile;
        
        bookFile.open(bookFileName, ios::app);
        bookFile << newBookRecord << endl;
        bookFile.close();
    }
    else
    {
        // Book exist, don't add redundant entry
        cout << "Book already exists in the library." << endl;
    }
}
